# Hemetroid 0.1.0-wip.1

First work-in-progress playtest, November 9, 2026.

- Three four-room areas: Deep Facility, Pipeworks, and Overflow Vault.
- Double Jump and Flush Dash carry forward as the campaign unlocks new areas.
- Automatic area checkpoints, replayable areas, original sound effects, and a mute toggle.
- Desktop keyboard play in a browser with WebGL. Progress is stored in the browser for the address you use to play.

Extract the ZIP and serve the extracted folder over HTTP. See README.md for a local launch command and controls. The same folder can be hosted under a subpath.

For playtest feedback, note your browser and the room where the issue occurred. Useful things to watch for are finding the next door, understanding the boss cues, and learning when to use Flush Dash.

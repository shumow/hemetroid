# Hemetroid 0.2.0-wip.1

- Play through Deep Facility, Pipeworks, and Overflow Vault as one connected campaign. Press Up or W at a marked transfer to travel in either direction once it opens.
- Explore the expanded, scrolling Intake. Open Pause → Map to find visited rooms, the last relay, and discovered ability gates. The map gradually reveals a toilet silhouette, with Maintenance Bay as the optional flush handle.
- Return to Relay Junction with Flush Dash and collect the Suit Patch in Maintenance Bay for one extra health pip.
- Continue Campaign resumes at the furthest area checkpoint. Existing saves can still load in the same browser at the same address. Replay Areas keeps campaign progress separate.

See README.md for controls and instructions for serving this folder over HTTP.
